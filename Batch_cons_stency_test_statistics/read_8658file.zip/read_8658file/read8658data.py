


import win32com.client as win32
import os.path
import os

import csv
import numpy as np
import openpyexcel
import openpyxl
import datetime


global excel_name
global text_name

def creat_excel_file():
    """以当前时间为名字，创建一个xlsx文件"""
    curr_time = datetime.datetime.now()
    text_name=str(curr_time.hour) + '_' + str(curr_time.minute) +'result'+ '.txt'
    excel_name = str(curr_time.hour) + '_' + str(curr_time.minute) +'raw_data'+ '.xlsx'
    wb = openpyxl.Workbook()
    wb.save(excel_name)

    wb = openpyexcel.load_workbook(excel_name)
    wb.save(excel_name)
    return excel_name,text_name

def  read_first_folder(rootdir):
    """本函数读取第一层文件夹下所有文件"""
    all_files = os.listdir(rootdir)  # 列出源地址文件夹下的所有文件
    # print(all_files)
    return all_files


def deal_with_data(second_name,f_csv,wb):
    """把数据写入excel文件，把计算的数值写到txt文件里"""
    name = second_name
    work_sheet = wb.create_sheet(title=name)
    for row in f_csv:
        work_sheet.append(row)
    column1 = [row[1:5] for row in f_csv]
    data = column1[2:]
    array1 = np.array(data)
    float_arr = array1.astype(np.float64)
    # 求均值
    mean_x = np.mean(float_arr[:, 0])
    mean_y = np.mean(float_arr[:, 1])
    mean_z = np.mean(float_arr[:, 2])
    mean_t = np.mean(float_arr[:, 3])
    mean_xyzt=[mean_x,mean_y,mean_z,mean_t]
    file_handle = open(text_name, mode='a+')
    name_avr = name+ '_average'+'     '
    file_handle.write(name_avr)
    for i in mean_xyzt:
        file_handle.write(str(i))
        file_handle.write('    ')
    file_handle.write('\n')
    file_handle.close()
    #求标准差
    std_x = np.std(float_arr[:, 0])
    std_y = np.std(float_arr[:, 1])
    std_z = np.std(float_arr[:, 2])
    std_xyz = [std_x, std_y, std_z]
    file_handle = open(text_name, mode='a+')
    name_std = name + '_std' + '     '
    file_handle.write(name_std)
    for i in std_xyz:
        file_handle.write(str(i))
        file_handle.write('    ')
    file_handle.write('\n')
    file_handle.close()

  


def deal_with(data_name,wb):
    """分类识别加速度数据，以及陀螺仪数据"""
    # print(data_name[-7:-4])
    with open(data_name) as f:
        f_csv = csv.reader(f)
        f_csv = [d for d in f_csv]
        if data_name[-7:-4]=='cel':
            sheet_name=data_name[-30:-4]
            # print(sheet_name)
            deal_with_data(sheet_name,f_csv,wb)
        elif data_name[-7:-4]=='yro':
            sheet_name=data_name[-29:-4]
            # print(sheet_name)
            deal_with_data(sheet_name, f_csv,wb)



def read_second_folder(second_name,wb):
    # print(second_name)
    """读取第二层文件下所有文件"""
    files = os.listdir(second_name)
    for data_name in files:
        if data_name[0:2]=='UI':
            data_name = second_name + '\\' + data_name
            deal_with(data_name,wb)
            






if __name__ == '__main__':

    [excel_name,text_name]=creat_excel_file()
    print(f'生成一个{excel_name}')
    print(f'生成一个{text_name}')

    rootdir=r'C:\Users\QST_0160\Desktop\1m' #改这里，定位到第一层文件夹


    print(f'源文件地址是{rootdir}')
    all_files=read_first_folder(rootdir)
    # print(all_files)

    # -------------拼接成第二层文件夹字符串开始----------
    second_folder=[];
    count=0;
    wb = openpyexcel.load_workbook(excel_name)
    for name in all_files:
        name=rootdir+'\\'+name
        second_folder.append(name)
    n_second_folders=len(second_folder)
    print(f'{rootdir}下面一共{n_second_folders}个子文件夹')
    # -------------拼接第二层文件结束---------------------

    #-----开始依次遍历第二层文件夹下所有csv文件并逐次计算--------------------
    for second_name in second_folder:
        read_second_folder(second_name,wb)
        count=count+1
        print(f'已经完成第{count}个二级文件夹，剩余{n_second_folders-count}个二级文件夹')
    #----------------遍历文件结束-----------------------
    print('数据较大，请等待excel文件保存')
    print('保存中...')
    if n_second_folders > 20:
        print('数据量较大，可以出去抽根烟')

    wb.save(excel_name)
    print('程序运行结束，请查看excel文件')